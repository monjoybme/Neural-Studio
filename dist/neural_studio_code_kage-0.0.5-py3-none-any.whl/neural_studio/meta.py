
class Dict(dict):

    def __init__(self,  ):
        pass